package com.team.marketd.domain;

import lombok.Data;

@Data
public class NoticeVo {

	private int nidx;
	private int midx;
	private String nsubject;
	private String ncontent;
	private String nwridate;
	private String nupdate;
	private String ndelyn;
	
}
