package com.team.marketd.domain;

import lombok.Data;

@Data

public class OrderVo {

	int oidx;
	int pidx;
	int midx;
	String oid;
	String obuydate;
	int omoney;
	String oip;
	String ofinal;
	String ocancle;
	String odelyn;
	
	
}
