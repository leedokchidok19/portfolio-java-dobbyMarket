package com.team.marketd.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class MemberVo {
	
	private int midx;
	private String mid;
	private String mpwd;
	private String mname;
	private String msex;
	private int mbirth;
	private String mtell;
	private String mkakao;
	private String mmail;
	private String mquestion;
	private int caidx;
	private long maccount;
	private String mkey;
	private Date mlimit;
	private String mip;
	private String mupdateip;
	private Date menter;
	private Date mupdate;
	private String mdelyn;
	private Date mdeldate;
	
	
	
	
	
	
	
	
	
}
