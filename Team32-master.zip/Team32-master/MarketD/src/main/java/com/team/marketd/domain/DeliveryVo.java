package com.team.marketd.domain;

import lombok.Data;

@Data
public class DeliveryVo {

	private int didx;
	private int oidx;
	private int caidx;
	private String drecipt;
	private String dtell;
	private String daddr;
	private String ddetails;
	private String dmemo;
	private int dwaybill;
	private String dsenddate;
	private String dcancle;
}