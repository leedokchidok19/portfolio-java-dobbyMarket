package com.team.marketd.domain;

import lombok.Data;

@Data
public class QuestionVo {
	
	private int qidx;
	private int midx;
	private int caidx;
	private String qsubject;
	private String qcontent;
	private String qwridate;
	private String qupdate;
	private String qresubject;
	private String qrecontent;
	private String qrewridate;
	private String qstate;
	private String qdelyn;
	private String mname;
	private String cate;

}
